This is a simple document explaining how to install and run the console program for Windows (64 bits)
MHall. A PDF document explaining the syntax of Hall symbols is also included.

Procedure:
 1: Extract the files of MHall.zip in the directory of your choice
 2: Open a Windows terminal (using cmd.exe) and go to the previous directory.
 3: Type MHall in the terminal followed by the <Enter> key.
 4: Introduce the Hall symbol of your choice (or a set of generators in Jones faithful notation separated by semicolons)
 5: Type the <Enter> key
 6: For exiting the program you should enter a void Hall symbol.
 
Notice that the database magnetic_data.txt, by Stokes & Campbell, is provided with the program. If you have already this
database in another directory you may define the environment variable CRYSFML_DB pointing to the directory where 
magnetic_data.txt is.

Examples giving the symbols at the command line:
================================================
MyPrompt> MHall "x,-y,z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1" > output.txt
MyPrompt> MHall "-F 2yw' -1'n" >> output.txt

This allows the preparation of a batch file for testing many examples at the fly. The standard output is sent to output.txt


A simple example without providing the symbol or the operators as arguments in the command line.
=============================================================================================== 
MyPrompt> MHall
  ----------------------------
   MHall: Testing Hall symbols
  ----------------------------
 => Enter the magnetic Hall symbol or a list of generators in Jones'faithful notation: x,-y,z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
 => Input generators: x,-y,z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
 => Deduced Hall symbol from generators: -C 2yw'
 => Obtained generators: -x,y,-z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
    General Space Group
    -------------------
                  Op-Dimension:    4
               Space-Dimension:    3
                  Multiplicity:   16
                       MagType:    3, Black-White:1
                        NumOps:    2
                       Centred:    2
     Num. Centring translation:    3
        Num. Anti-translations:    0
                Crystal system: Monoclinic
  Crystallographic Point group: 2/m
                    Laue class: 2/m
            Space Group number:   15
        Shubnikov Group number:   96
                   Hall symbol: -C 2yw'
    Shubnikov Group BNS-symbol: C2'/c'
    Shubnikov Group BNS-label : 15.89
    Shubnikov Group  OG-symbol: C2'/c'
          Magnetic Point Group: 2'/m'
   To Standard Shubnikov Group: a,-b,-c/2;0,0,0
               Generators List: -x,y,-z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
                  Centre_coord: [ 0 0 0 ]

         Centring translations:
                               [ 1/2 1/2 0 ]
                               [ 0 0 1/2 ]
                               [ 1/2 1/2 1/2 ]

  Complete list of symmetry operators and symmetry symbols
  ========================================================
  SymmOp   1: x,y,z,1                             Symbol: 1
  SymmOp   2: -x,y,-z+1/4,-1                      Symbol: 2' 0,y,1/8
  SymmOp   3: -x,-y,-z,1                          Symbol: -1 0,0,0
  SymmOp   4: x,-y,z+3/4,-1                       Symbol: g' (0,0,3/4) x,0,z
  SymmOp   5: x+1/2,y+1/2,z,1                     Symbol: t (1/2,1/2,0)
  SymmOp   6: -x+1/2,y+1/2,-z+1/4,-1              Symbol: 2' (0,1/2,0) 1/4,y,1/8
  SymmOp   7: -x+1/2,-y+1/2,-z,1                  Symbol: -1 1/4,1/4,0
  SymmOp   8: x+1/2,-y+1/2,z+3/4,-1               Symbol: g' (1/2,0,3/4) x,1/4,z
  SymmOp   9: x,y,z+1/2,1                         Symbol: t (0,0,1/2)
  SymmOp  10: -x,y,-z+3/4,-1                      Symbol: 2' 0,y,3/8
  SymmOp  11: -x,-y,-z+1/2,1                      Symbol: -1 0,0,1/4
  SymmOp  12: x,-y,z+1/4,-1                       Symbol: g' (0,0,1/4) x,0,z
  SymmOp  13: x+1/2,y+1/2,z+1/2,1                 Symbol: t (1/2,1/2,1/2)
  SymmOp  14: -x+1/2,y+1/2,-z+3/4,-1              Symbol: 2' (0,1/2,0) 1/4,y,3/8
  SymmOp  15: -x+1/2,-y+1/2,-z+1/2,1              Symbol: -1 1/4,1/4,1/4
  SymmOp  16: x+1/2,-y+1/2,z+1/4,-1               Symbol: g' (1/2,0,1/4) x,1/4,z

 => Total CPU_TIME for this calculation:        0.438 seconds
  ----------------------------
   MHall: Testing Hall symbols
  ----------------------------
 => Enter the magnetic Hall symbol or a list of generators in Jones'faithful notation: -C 2yw'
 => Obtained generators: -x,y,-z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
    General Space Group
    -------------------
                  Op-Dimension:    4
               Space-Dimension:    3
                  Multiplicity:   16
                       MagType:    3, Black-White:1
                        NumOps:    2
                       Centred:    2
     Num. Centring translation:    3
        Num. Anti-translations:    0
                Crystal system: Monoclinic
  Crystallographic Point group: 2/m
                    Laue class: 2/m
            Space Group number:   15
        Shubnikov Group number:   96
                   Hall symbol: -C 2yw'
    Shubnikov Group BNS-symbol: C2'/c'
    Shubnikov Group BNS-label : 15.89
    Shubnikov Group  OG-symbol: C2'/c'
          Magnetic Point Group: 2'/m'
   To Standard Shubnikov Group: a,-b,-c/2;0,0,0
               Generators List: -x,y,-z+1/4,-1;-x,-y,-z,1;x+1/2,y+1/2,z,1
                  Centre_coord: [ 0 0 0 ]

         Centring translations:
                               [ 1/2 1/2 0 ]
                               [ 0 0 1/2 ]
                               [ 1/2 1/2 1/2 ]

  Complete list of symmetry operators and symmetry symbols
  ========================================================
  SymmOp   1: x,y,z,1                             Symbol: 1
  SymmOp   2: -x,y,-z+1/4,-1                      Symbol: 2' 0,y,1/8
  SymmOp   3: -x,-y,-z,1                          Symbol: -1 0,0,0
  SymmOp   4: x,-y,z+3/4,-1                       Symbol: g' (0,0,3/4) x,0,z
  SymmOp   5: x+1/2,y+1/2,z,1                     Symbol: t (1/2,1/2,0)
  SymmOp   6: -x+1/2,y+1/2,-z+1/4,-1              Symbol: 2' (0,1/2,0) 1/4,y,1/8
  SymmOp   7: -x+1/2,-y+1/2,-z,1                  Symbol: -1 1/4,1/4,0
  SymmOp   8: x+1/2,-y+1/2,z+3/4,-1               Symbol: g' (1/2,0,3/4) x,1/4,z
  SymmOp   9: x,y,z+1/2,1                         Symbol: t (0,0,1/2)
  SymmOp  10: -x,y,-z+3/4,-1                      Symbol: 2' 0,y,3/8
  SymmOp  11: -x,-y,-z+1/2,1                      Symbol: -1 0,0,1/4
  SymmOp  12: x,-y,z+1/4,-1                       Symbol: g' (0,0,1/4) x,0,z
  SymmOp  13: x+1/2,y+1/2,z+1/2,1                 Symbol: t (1/2,1/2,1/2)
  SymmOp  14: -x+1/2,y+1/2,-z+3/4,-1              Symbol: 2' (0,1/2,0) 1/4,y,3/8
  SymmOp  15: -x+1/2,-y+1/2,-z+1/2,1              Symbol: -1 1/4,1/4,1/4
  SymmOp  16: x+1/2,-y+1/2,z+1/4,-1               Symbol: g' (1/2,0,1/4) x,1/4,z

 => Total CPU_TIME for this calculation:        0.031 seconds
  ----------------------------
   MHall: Testing Hall symbols
  ----------------------------
 => Enter the magnetic Hall symbol or a list of generators in Jones'faithful notation: 
 
